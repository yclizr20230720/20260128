"""
VSMC Litho Platform - Application Entry Point
"""
import os
from app import create_app

# Get configuration from environment or use default
config_name = os.getenv('FLASK_ENV', 'development')

# Create Flask application
app = create_app(config_name)

if __name__ == '__main__':
    # Run the application
    port = int(os.getenv('PORT', 5000))
    debug = config_name == 'development'
    
    print("="*70)
    print("VSMC Litho Platform - Backend API")
    print("="*70)
    print(f"Environment: {config_name}")
    print(f"Port: {port}")
    print(f"Debug: {debug}")
    print("="*70)
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=debug
    )
