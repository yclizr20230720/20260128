"""
API Routes for VSMC Litho Platform
"""
from .health import health_bp
from .edforest import edforest_bp

__all__ = ['health_bp', 'edforest_bp']
