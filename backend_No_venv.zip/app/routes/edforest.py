"""
EDForest / Bossung Curve Analysis Endpoints
"""
from flask import Blueprint, request, jsonify, send_file, current_app
from werkzeug.utils import secure_filename
import os
import pandas as pd
from app.services.bossung_service import BossungService
from app.utils.file_handler import allowed_file, save_upload_file

edforest_bp = Blueprint('edforest', __name__)
bossung_service = BossungService()


@edforest_bp.route('/upload', methods=['POST'])
def upload_data():
    """
    Upload lithography data CSV file
    
    Expected CSV format:
    Dose,Defocus,CD,Wafer_ID,Field
    
    Returns:
    --------
    JSON response with file info and data preview
    """
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename, current_app.config['ALLOWED_EXTENSIONS']):
            return jsonify({'error': 'Invalid file type. Allowed: CSV, TXT, XLSX'}), 400
        
        # Save file
        filename = secure_filename(file.filename)
        filepath = save_upload_file(file, filename, current_app.config['UPLOAD_FOLDER'])
        
        # Read and validate data
        try:
            data = pd.read_csv(filepath)
            
            # Validate required columns
            required_cols = ['Dose', 'Defocus', 'CD']
            missing_cols = [col for col in required_cols if col not in data.columns]
            
            if missing_cols:
                return jsonify({
                    'error': f'Missing required columns: {", ".join(missing_cols)}',
                    'required': required_cols,
                    'found': list(data.columns)
                }), 400
            
            # Get data summary
            summary = {
                'filename': filename,
                'filepath': filepath,
                'rows': len(data),
                'columns': list(data.columns),
                'dose_range': {
                    'min': float(data['Dose'].min()),
                    'max': float(data['Dose'].max()),
                    'unique': int(data['Dose'].nunique())
                },
                'defocus_range': {
                    'min': float(data['Defocus'].min()),
                    'max': float(data['Defocus'].max()),
                    'unique': int(data['Defocus'].nunique())
                },
                'cd_range': {
                    'min': float(data['CD'].min()),
                    'max': float(data['CD'].max()),
                    'mean': float(data['CD'].mean()),
                    'std': float(data['CD'].std())
                },
                'preview': data.head(10).to_dict('records')
            }
            
            return jsonify({
                'success': True,
                'message': 'File uploaded successfully',
                'data': summary
            }), 200
            
        except Exception as e:
            return jsonify({'error': f'Error reading file: {str(e)}'}), 400
            
    except Exception as e:
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500


@edforest_bp.route('/analyze', methods=['POST'])
def analyze_bossung():
    """
    Analyze Bossung curves and calculate process window metrics
    
    Request JSON:
    {
        "filepath": "path/to/data.csv",
        "target_cd": 45.0,
        "tolerance_percent": 10
    }
    
    Returns:
    --------
    JSON response with analysis results AND chart data
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        filepath = data.get('filepath')
        target_cd = data.get('target_cd', 45.0)
        tolerance_percent = data.get('tolerance_percent', 10)
        
        if not filepath or not os.path.exists(filepath):
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Perform analysis
        results = bossung_service.analyze(filepath, target_cd, tolerance_percent)
        
        # Get chart data for frontend rendering
        chart_data = bossung_service.get_chart_data(filepath, target_cd, tolerance_percent)
        
        return jsonify({
            'success': True,
            'results': results,
            'chart_data': chart_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500


@edforest_bp.route('/generate-plots', methods=['POST'])
def generate_plots():
    """
    Generate Bossung curve plots
    
    Request JSON:
    {
        "filepath": "path/to/data.csv",
        "target_cd": 45.0,
        "tolerance_percent": 10,
        "plot_types": ["bossung", "process_window", "comprehensive"]
    }
    
    Returns:
    --------
    JSON response with plot file paths
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        filepath = data.get('filepath')
        target_cd = data.get('target_cd', 45.0)
        tolerance_percent = data.get('tolerance_percent', 10)
        plot_types = data.get('plot_types', ['bossung', 'process_window', 'comprehensive'])
        
        if not filepath or not os.path.exists(filepath):
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Generate plots
        output_folder = current_app.config['OUTPUT_FOLDER']
        plot_files = bossung_service.generate_plots(
            filepath, target_cd, tolerance_percent, plot_types, output_folder
        )
        
        return jsonify({
            'success': True,
            'plots': plot_files
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Plot generation failed: {str(e)}'}), 500


@edforest_bp.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    """
    Download generated plot or report file
    
    Parameters:
    -----------
    filename : str
        Name of file to download
    
    Returns:
    --------
    File download
    """
    try:
        output_folder = current_app.config['OUTPUT_FOLDER']
        filepath = os.path.join(output_folder, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        return send_file(filepath, as_attachment=True)
        
    except Exception as e:
        return jsonify({'error': f'Download failed: {str(e)}'}), 500


@edforest_bp.route('/generate-mock-data', methods=['POST'])
def generate_mock_data():
    """
    Generate mock lithography data for testing
    
    Request JSON:
    {
        "doses": 9,
        "defocus_points": 17,
        "target_cd": 45.0
    }
    
    Returns:
    --------
    JSON response with generated data file path
    """
    try:
        data = request.get_json() or {}
        
        doses = data.get('doses', 9)
        defocus_points = data.get('defocus_points', 17)
        target_cd = data.get('target_cd', 45.0)
        
        # Generate mock data
        upload_folder = current_app.config['UPLOAD_FOLDER']
        filepath = bossung_service.generate_mock_data(
            upload_folder, doses, defocus_points, target_cd
        )
        
        # Read generated data for preview
        df = pd.read_csv(filepath)
        
        return jsonify({
            'success': True,
            'message': 'Mock data generated successfully',
            'filepath': filepath,
            'filename': os.path.basename(filepath),
            'rows': len(df),
            'preview': df.head(10).to_dict('records')
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Mock data generation failed: {str(e)}'}), 500
