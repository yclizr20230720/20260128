"""
User model for authentication
"""
import json
import os
from datetime import datetime
import bcrypt

class UserModel:
    def __init__(self, users_file='users.json'):
        # Get the directory where this file is located
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.users_file = os.path.join(base_dir, users_file)
        self._ensure_file_exists()
    
    def _ensure_file_exists(self):
        """Create users file if it doesn't exist"""
        if not os.path.exists(self.users_file):
            # Create default admin user
            default_users = {
                "admin": {
                    "username": "admin",
                    "email": "admin@vsmc.com",
                    "password": self._hash_password("admin123"),
                    "role": "admin",
                    "created_at": datetime.now().isoformat(),
                    "last_login": None
                }
            }
            with open(self.users_file, 'w') as f:
                json.dump(default_users, f, indent=2)
    
    def _hash_password(self, password):
        """Hash password using bcrypt"""
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def _verify_password(self, password, hashed):
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def _load_users(self):
        """Load users from file"""
        with open(self.users_file, 'r') as f:
            return json.load(f)
    
    def _save_users(self, users):
        """Save users to file"""
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=2)
    
    def create_user(self, username, email, password, role='user'):
        """Create a new user"""
        users = self._load_users()
        
        # Check if user exists
        if username in users:
            return None, "Username already exists"
        
        # Check if email exists
        for user in users.values():
            if user['email'] == email:
                return None, "Email already exists"
        
        # Create user
        users[username] = {
            "username": username,
            "email": email,
            "password": self._hash_password(password),
            "role": role,
            "created_at": datetime.now().isoformat(),
            "last_login": None
        }
        
        self._save_users(users)
        
        # Return user without password
        user_data = users[username].copy()
        del user_data['password']
        return user_data, None
    
    def authenticate(self, username, password):
        """Authenticate user"""
        users = self._load_users()
        
        if username not in users:
            return None, "Invalid username or password"
        
        user = users[username]
        
        if not self._verify_password(password, user['password']):
            return None, "Invalid username or password"
        
        # Update last login
        users[username]['last_login'] = datetime.now().isoformat()
        self._save_users(users)
        
        # Return user without password
        user_data = user.copy()
        del user_data['password']
        return user_data, None
    
    def get_user(self, username):
        """Get user by username"""
        users = self._load_users()
        
        if username not in users:
            return None
        
        user_data = users[username].copy()
        del user_data['password']
        return user_data
    
    def get_all_users(self):
        """Get all users (admin only)"""
        users = self._load_users()
        result = []
        
        for user in users.values():
            user_data = user.copy()
            del user_data['password']
            result.append(user_data)
        
        return result
    
    def update_user(self, username, **kwargs):
        """Update user information"""
        users = self._load_users()
        
        if username not in users:
            return None, "User not found"
        
        # Update allowed fields
        allowed_fields = ['email', 'role']
        for field in allowed_fields:
            if field in kwargs:
                users[username][field] = kwargs[field]
        
        # Update password if provided
        if 'password' in kwargs:
            users[username]['password'] = self._hash_password(kwargs['password'])
        
        self._save_users(users)
        
        user_data = users[username].copy()
        del user_data['password']
        return user_data, None
    
    def delete_user(self, username):
        """Delete user"""
        users = self._load_users()
        
        if username not in users:
            return False, "User not found"
        
        if username == 'admin':
            return False, "Cannot delete admin user"
        
        del users[username]
        self._save_users(users)
        
        return True, None
