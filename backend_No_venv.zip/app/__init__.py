"""
VSMC Litho Platform - Flask Application Factory
"""
from flask import Flask
from flask_cors import CORS
from config import config
import os


def create_app(config_name='development'):
    """
    Create and configure the Flask application
    
    Parameters:
    -----------
    config_name : str
        Configuration name ('development', 'production', 'testing')
    
    Returns:
    --------
    Flask app instance
    """
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Initialize CORS
    CORS(app, resources={
        r"/api/*": {
            "origins": app.config['CORS_ORIGINS'],
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })
    
    # Register blueprints
    from app.routes import health_bp, edforest_bp
    from app.routes.history import history_bp
    from app.routes.auth import auth_bp
    
    api_prefix = app.config['API_PREFIX']
    app.register_blueprint(health_bp, url_prefix=f'{api_prefix}/health')
    app.register_blueprint(edforest_bp, url_prefix=f'{api_prefix}/edforest')
    app.register_blueprint(history_bp, url_prefix=f'{api_prefix}/history')
    app.register_blueprint(auth_bp, url_prefix=f'{api_prefix}/auth')
    
    # Root endpoint
    @app.route('/')
    def index():
        return {
            'name': 'VSMC Litho Platform API',
            'version': app.config['API_VERSION'],
            'status': 'running',
            'endpoints': {
                'health': f'{api_prefix}/health',
                'auth': f'{api_prefix}/auth',
                'edforest': f'{api_prefix}/edforest',
                'history': f'{api_prefix}/history'
            }
        }
    
    return app
